<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible"
	content="IE=edge">
	<title>Trang Chủ | <?php echo $__env->yieldContent('title'); ?></title>
	<link rel="stylesheet" href="">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
	<h1>NamproBlog</h1>
	<!--Main-->
	<?php echo $__env->yieldContent('main'); ?>
</body>
</html>
<?php /* D:\xampp\htdocs\blog\local\resources\views/master.blade.php */ ?>