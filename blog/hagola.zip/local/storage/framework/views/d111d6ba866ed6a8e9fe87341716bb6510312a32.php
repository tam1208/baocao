<h1>Hello Laravel</h1>
<h2>This is my first view</h2>














<?php /* D:\xampp\htdocs\blog\local\resources\views/MyFirstView.blade.php */ ?>