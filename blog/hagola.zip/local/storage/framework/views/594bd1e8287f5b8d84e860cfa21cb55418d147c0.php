<?php $__env->startSection('title','Bài viết'); ?>
<?php $__env->startSection('main'); ?>
<h1>Bài Viết</h1>
<?php echo $__env->make('errors/note', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<ul>
	<li>Samsung Galaxy Note 7 phát nổ</li>
	<li>Iphone 6S tróc sơn</li>
	<li>Macbook 2016 bỏ cổng MacSafe</li>
	<li>LG V20 không ai mua</li>
</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\xampp\htdocs\blog\local\resources\views/post.blade.php */ ?>