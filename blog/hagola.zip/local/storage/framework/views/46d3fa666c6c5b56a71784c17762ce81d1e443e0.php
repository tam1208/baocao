<h1>Error 404</h1>
<h2>Your page is not found</h2>
<?php /* D:\xampp\htdocs\blog\local\resources\views/errors/404.blade.php */ ?>