<?php $__env->startSection('title','Danh mục'); ?>
<?php $__env->startSection('main'); ?>
<h1>Danh Mục</h1>
<ul>
	<li>Điện thoại</li>
	<li>Máy tính bảng</li>
	<li>Máy nghe nhạc</li>
	<li>Máy ảnh</li>
</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\xampp\htdocs\blog\local\resources\views/category.blade.php */ ?>