<h1>Hello Laravel</h1>
<h2>This is my first view</h2>


{{-- @if($so>0)
	<p>Số dương</p>
@elseif($so<0)
	<p>Số âm</p>
@else
	<p>Số không</p>
@endif --}}


{{-- @for($i=1;$i<=10;$i++)
	{{$i}}<br> 
@endfor --}}


{{-- @while($so<=10)
	{{$so}}
	@php
		$so++
	@endphp
@endwhile --}}


{{-- @foreach($postname as $value)
	{{$value}}<br>
@endforeach --}}

