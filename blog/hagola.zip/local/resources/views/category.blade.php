@extends('master')
@section('title','Danh mục')
@section('main')
<h1>Danh Mục</h1>
<ul>
	<li>Điện thoại</li>
	<li>Máy tính bảng</li>
	<li>Máy nghe nhạc</li>
	<li>Máy ảnh</li>
</ul>
@stop