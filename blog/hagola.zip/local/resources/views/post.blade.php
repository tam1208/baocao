@extends('master')
@section('title','Bài viết')
@section('main')
<h1>Bài Viết</h1>
@include('errors/note')
<ul>
	<li>Samsung Galaxy Note 7 phát nổ</li>
	<li>Iphone 6S tróc sơn</li>
	<li>Macbook 2016 bỏ cổng MacSafe</li>
	<li>LG V20 không ai mua</li>
</ul>
@stop